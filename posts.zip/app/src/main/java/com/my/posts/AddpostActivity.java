package com.my.posts;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.support.v7.app.AppCompatActivity;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.ImageView;
import android.content.Intent;
import android.net.Uri;
import android.app.Activity;
import android.content.SharedPreferences;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import android.content.ClipData;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.firebase.storage.OnProgressListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.OnFailureListener;
import java.io.File;
import android.view.View;
import android.graphics.Typeface;
import com.bumptech.glide.Glide;
import android.support.v4.content.ContextCompat;
import android.support.v4.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class AddpostActivity extends AppCompatActivity {
	
	public final int REQ_CD_FILEPICKER = 101;
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private HashMap<String, Object> post = new HashMap<>();
	private String imageurl = "";
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private TextView textview4;
	private LinearLayout linear3;
	private EditText name;
	private LinearLayout linear9;
	private TextView textview5;
	private ScrollView vscroll1;
	private TextView textview1;
	private ImageView addpost;
	private ImageView imageview2;
	private EditText theme;
	private TextView grey;
	private TextView red;
	private TextView purple;
	private TextView blue;
	private TextView yellow;
	private LinearLayout linear10;
	private EditText edittext3;
	private TextView addphoto;
	private ImageView imageview3;
	
	private Intent intent = new Intent();
	private SharedPreferences save;
	private DatabaseReference data = _firebase.getReference("posts");
	private ChildEventListener _data_child_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private Intent filepicker = new Intent(Intent.ACTION_GET_CONTENT);
	private StorageReference storage = _firebase_storage.getReference("images");
	private OnSuccessListener<UploadTask.TaskSnapshot> _storage_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _storage_download_success_listener;
	private OnSuccessListener _storage_delete_success_listener;
	private OnProgressListener _storage_upload_progress_listener;
	private OnProgressListener _storage_download_progress_listener;
	private OnFailureListener _storage_failure_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.addpost);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		textview4 = (TextView) findViewById(R.id.textview4);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		name = (EditText) findViewById(R.id.name);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		textview5 = (TextView) findViewById(R.id.textview5);
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		textview1 = (TextView) findViewById(R.id.textview1);
		addpost = (ImageView) findViewById(R.id.addpost);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		theme = (EditText) findViewById(R.id.theme);
		grey = (TextView) findViewById(R.id.grey);
		red = (TextView) findViewById(R.id.red);
		purple = (TextView) findViewById(R.id.purple);
		blue = (TextView) findViewById(R.id.blue);
		yellow = (TextView) findViewById(R.id.yellow);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		edittext3 = (EditText) findViewById(R.id.edittext3);
		addphoto = (TextView) findViewById(R.id.addphoto);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		save = getSharedPreferences("save", Activity.MODE_PRIVATE);
		auth = FirebaseAuth.getInstance();
		filepicker.setType("image/*");
		filepicker.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		
		addpost.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				post = new HashMap<>();
				post.put("author", save.getString("name", ""));
				post.put("authormail", FirebaseAuth.getInstance().getCurrentUser().getEmail());
				post.put("authorid", FirebaseAuth.getInstance().getCurrentUser().getUid());
				post.put("verify", save.getString("verify", ""));
				post.put("name", name.getText().toString());
				post.put("theme", theme.getText().toString());
				post.put("likes", "0");
				post.put("id", data.push().getKey());
				post.put("views", "0");
				post.put("text", edittext3.getText().toString());
				post.put("image", imageurl);
				if (save.getString("postcolor", "").equals("grey")) {
					post.put("color", "grey");
				}
				if (save.getString("postcolor", "").equals("red")) {
					post.put("color", "red");
				}
				if (save.getString("postcolor", "").equals("purple")) {
					post.put("color", "purple");
				}
				if (save.getString("postcolor", "").equals("blue")) {
					post.put("color", "blue");
				}
				if (save.getString("postcolor", "").equals("yellow")) {
					post.put("color", "yellow");
				}
				if (save.getString("postcolor", "").equals("")) {
					post.put("color", "grey");
				}
				data.child(post.get("id").toString()).updateChildren(post);
				SketchwareUtil.showMessage(getApplicationContext(), "Вы создали статью!");
				save.edit().putString("postcolor", "").commit();
				intent.setClass(getApplicationContext(), MainActivity.class);
				startActivity(intent);
			}
		});
		
		grey.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				save.edit().putString("postcolor", "grey").commit();
				grey.setAlpha((float)(1));
				red.setAlpha((float)(0.5d));
				purple.setAlpha((float)(0.5d));
				blue.setAlpha((float)(0.5d));
				yellow.setAlpha((float)(0.5d));
			}
		});
		
		red.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				save.edit().putString("postcolor", "red").commit();
				red.setAlpha((float)(1));
				grey.setAlpha((float)(0.5d));
				purple.setAlpha((float)(0.5d));
				blue.setAlpha((float)(0.5d));
				yellow.setAlpha((float)(0.5d));
			}
		});
		
		purple.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				save.edit().putString("postcolor", "purple").commit();
				purple.setAlpha((float)(1));
				grey.setAlpha((float)(0.5d));
				red.setAlpha((float)(0.5d));
				blue.setAlpha((float)(0.5d));
				yellow.setAlpha((float)(0.5d));
			}
		});
		
		blue.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				save.edit().putString("postcolor", "blue").commit();
				blue.setAlpha((float)(1));
				grey.setAlpha((float)(0.5d));
				red.setAlpha((float)(0.5d));
				purple.setAlpha((float)(0.5d));
				yellow.setAlpha((float)(0.5d));
			}
		});
		
		yellow.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				save.edit().putString("postcolor", "yellow").commit();
				grey.setAlpha((float)(0.5d));
				red.setAlpha((float)(0.5d));
				purple.setAlpha((float)(0.5d));
				blue.setAlpha((float)(0.5d));
				yellow.setAlpha((float)(1));
			}
		});
		
		addphoto.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(filepicker, REQ_CD_FILEPICKER);
			}
		});
		
		_data_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		data.addChildEventListener(_data_child_listener);
		
		_storage_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_storage_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_storage_upload_success_listener = new OnSuccessListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(UploadTask.TaskSnapshot _param1) {
				final String _downloadUrl = _param1.getDownloadUrl().toString();
				imageurl = _downloadUrl;
				SketchwareUtil.showMessage(getApplicationContext(), "Вы успешно добавили изображение!");
				
				imageview3.setVisibility(View.VISIBLE);
				Glide.with(getApplicationContext()).load(Uri.parse(_downloadUrl)).into(imageview3);
			}
		};
		
		_storage_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_storage_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_storage_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
		imageurl = "";
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/black.ttf"), 0);
		textview4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/bold.ttf"), 0);
		textview5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/bold.ttf"), 0);
		name.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/black.ttf"), 0);
		theme.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/bold.ttf"), 0);
		edittext3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/meduim.ttf"), 0);
		imageview3.setVisibility(View.GONE);
		android.graphics.drawable.GradientDrawable tt1 = new android.graphics.drawable.GradientDrawable(); tt1.setColor(Color.parseColor("#BDBDBD")); tt1.setCornerRadius(36); grey.setBackground(tt1);
		android.graphics.drawable.GradientDrawable tt2 = new android.graphics.drawable.GradientDrawable(); tt2.setColor(Color.parseColor("#E57373")); tt2.setCornerRadius(36); red.setBackground(tt2);
		android.graphics.drawable.GradientDrawable tt3 = new android.graphics.drawable.GradientDrawable(); tt3.setColor(Color.parseColor("#7E57C2")); tt3.setCornerRadius(36); purple.setBackground(tt3);
		android.graphics.drawable.GradientDrawable tt4 = new android.graphics.drawable.GradientDrawable(); tt4.setColor(Color.parseColor("#64B5F6")); tt4.setCornerRadius(36); blue.setBackground(tt4);
		android.graphics.drawable.GradientDrawable tt5 = new android.graphics.drawable.GradientDrawable(); tt5.setColor(Color.parseColor("#FFCA28")); tt5.setCornerRadius(36); yellow.setBackground(tt5);
		android.graphics.drawable.GradientDrawable tt7 = new android.graphics.drawable.GradientDrawable(); tt7.setColor(Color.parseColor("#000000")); tt7.setCornerRadius(24); addphoto.setBackground(tt7);
		addphoto.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/bold.ttf"), 0);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_FILEPICKER:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				storage.child(Uri.parse(_filePath.get((int)(0))).getLastPathSegment()).putFile(Uri.fromFile(new File(_filePath.get((int)(0))))).addOnSuccessListener(_storage_upload_success_listener).addOnFailureListener(_storage_failure_listener).addOnProgressListener(_storage_upload_progress_listener);
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
