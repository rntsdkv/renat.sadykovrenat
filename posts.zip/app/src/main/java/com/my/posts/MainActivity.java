package com.my.posts;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.support.v7.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.content.Intent;
import android.net.Uri;
import android.app.Activity;
import android.content.SharedPreferences;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import android.widget.AdapterView;
import android.view.View;
import android.graphics.Typeface;

public class MainActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private double j = 0;
	private String status = "";
	
	private ArrayList<HashMap<String, Object>> posts = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> userlist = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private TextView addpost;
	private ListView listview1;
	private TextView textview2;
	private LinearLayout linear3;
	private ImageView imageview3;
	private ImageView gochats;
	private ImageView goprofile;
	
	private Intent intent = new Intent();
	private SharedPreferences save;
	private DatabaseReference data = _firebase.getReference("posts");
	private ChildEventListener _data_child_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private DatabaseReference datausers = _firebase.getReference("users");
	private ChildEventListener _datausers_child_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		addpost = (TextView) findViewById(R.id.addpost);
		listview1 = (ListView) findViewById(R.id.listview1);
		textview2 = (TextView) findViewById(R.id.textview2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		gochats = (ImageView) findViewById(R.id.gochats);
		goprofile = (ImageView) findViewById(R.id.goprofile);
		save = getSharedPreferences("save", Activity.MODE_PRIVATE);
		auth = FirebaseAuth.getInstance();
		
		addpost.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (save.getString("mail", "").equals("")) {
					SketchwareUtil.showMessage(getApplicationContext(), "Авторизуйтесь перед созданием статьи!");
					intent.setClass(getApplicationContext(), RegistrationActivity.class);
					startActivity(intent);
				}
				else {
					if (Double.parseDouble(save.getString("rating", "")) > 10) {
						intent.setClass(getApplicationContext(), AddpostActivity.class);
						startActivity(intent);
					}
					else {
						SketchwareUtil.showMessage(getApplicationContext(), "Для создания статьи нужно иметь более 10 очков рейтинга!");
					}
				}
			}
		});
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				intent.setClass(getApplicationContext(), PostviewActivity.class);
				intent.putExtra("name", posts.get((int)_position).get("name").toString());
				intent.putExtra("theme", posts.get((int)_position).get("theme").toString());
				intent.putExtra("likes", posts.get((int)_position).get("likes").toString());
				intent.putExtra("id", posts.get((int)_position).get("id").toString());
				intent.putExtra("text", posts.get((int)_position).get("text").toString());
				intent.putExtra("author", posts.get((int)_position).get("author").toString());
				intent.putExtra("authorverify", posts.get((int)_position).get("verify").toString());
				intent.putExtra("imageurl", posts.get((int)_position).get("image").toString());
				startActivity(intent);
			}
		});
		
		listview1.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				
				return true;
			}
		});
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FirebaseAuth.getInstance().signOut();
				save.edit().putString("mail", "").commit();
				save.edit().putString("password", "").commit();
			}
		});
		
		gochats.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), ChatviewActivity.class);
				startActivity(intent);
			}
		});
		
		_data_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				data.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						posts = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								posts.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						listview1.setAdapter(new Listview1Adapter(posts));
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		data.addChildEventListener(_data_child_listener);
		
		_datausers_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		datausers.addChildEventListener(_datausers_child_listener);
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
		setTitle("Статьи");
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/black.ttf"), 0);
		if (!save.getString("mail", "").equals("") || !save.getString("password", "").equals("")) {
			auth.signInWithEmailAndPassword(save.getString("mail", ""), save.getString("password", "")).addOnCompleteListener(MainActivity.this, _auth_sign_in_listener);
			_get(save.getString("mail", ""));
		}
		android.graphics.drawable.GradientDrawable tt = new android.graphics.drawable.GradientDrawable(); tt.setColor(Color.parseColor("#000000")); tt.setCornerRadius(24); addpost.setBackground(tt);
		addpost.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/bold.ttf"), 0);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _get (final String _name) {
		j = 0;
		datausers.addListenerForSingleValueEvent(new ValueEventListener() {
			@Override
			public void onDataChange(DataSnapshot _dataSnapshot) {
				userlist = new ArrayList<>();
				try {
					GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
					for (DataSnapshot _data : _dataSnapshot.getChildren()) {
						HashMap<String, Object> _map = _data.getValue(_ind);
						userlist.add(_map);
					}
				}
				catch (Exception _e) {
					_e.printStackTrace();
				}
				for(int _repeat12 = 0; _repeat12 < (int)(userlist.size()); _repeat12++) {
					if (_name.equals(userlist.get((int)j).get("mail").toString())) {
						save.edit().putString("name", userlist.get((int)j).get("name").toString()).commit();
						save.edit().putString("rating", userlist.get((int)j).get("rating").toString()).commit();
						save.edit().putString("verify", userlist.get((int)j).get("verify").toString()).commit();
						break;
					}
					else {
						if (j == (userlist.size() - 1)) {
							
						}
					}
					j++;
				}
			}
			@Override
			public void onCancelled(DatabaseError _databaseError) {
			}
		});
	}
	
	
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.post, null);
			}
			
			final LinearLayout linear5 = (LinearLayout) _v.findViewById(R.id.linear5);
			final TextView namep = (TextView) _v.findViewById(R.id.namep);
			final LinearLayout linear1 = (LinearLayout) _v.findViewById(R.id.linear1);
			final LinearLayout linear4 = (LinearLayout) _v.findViewById(R.id.linear4);
			final ImageView imageview3 = (ImageView) _v.findViewById(R.id.imageview3);
			final TextView themep = (TextView) _v.findViewById(R.id.themep);
			final ImageView imageview2 = (ImageView) _v.findViewById(R.id.imageview2);
			final TextView likesp = (TextView) _v.findViewById(R.id.likesp);
			
			namep.setText(posts.get((int)_position).get("name").toString());
			themep.setText(posts.get((int)_position).get("theme").toString());
			likesp.setText(posts.get((int)_position).get("likes").toString());
			namep.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/black.ttf"), 0);
			themep.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/bold.ttf"), 0);
			likesp.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/meduim.ttf"), 0);
			if (posts.get((int)_position).get("color").toString().equals("grey")) {
				android.graphics.drawable.GradientDrawable tt1 = new android.graphics.drawable.GradientDrawable(); tt1.setColor(Color.parseColor("#BDBDBD")); tt1.setCornerRadius(36); namep.setBackground(tt1);
				namep.setTextColor(0xFF000000);
			}
			if (posts.get((int)_position).get("color").toString().equals("red")) {
				android.graphics.drawable.GradientDrawable tt2 = new android.graphics.drawable.GradientDrawable(); tt2.setColor(Color.parseColor("#E57373")); tt2.setCornerRadius(36); namep.setBackground(tt2);
				namep.setTextColor(0xFFFFFFFF);
			}
			if (posts.get((int)_position).get("color").toString().equals("purple")) {
				android.graphics.drawable.GradientDrawable tt3 = new android.graphics.drawable.GradientDrawable(); tt3.setColor(Color.parseColor("#7E57C2")); tt3.setCornerRadius(36); namep.setBackground(tt3);
				namep.setTextColor(0xFFFFFFFF);
			}
			if (posts.get((int)_position).get("color").toString().equals("blue")) {
				android.graphics.drawable.GradientDrawable tt4 = new android.graphics.drawable.GradientDrawable(); tt4.setColor(Color.parseColor("#64B5F6")); tt4.setCornerRadius(36); namep.setBackground(tt4);
				namep.setTextColor(0xFFFFFFFF);
			}
			if (posts.get((int)_position).get("color").toString().equals("yellow")) {
				android.graphics.drawable.GradientDrawable tt5 = new android.graphics.drawable.GradientDrawable(); tt5.setColor(Color.parseColor("#FFCA28")); tt5.setCornerRadius(36); namep.setBackground(tt5);
				namep.setTextColor(0xFF000000);
			}
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
