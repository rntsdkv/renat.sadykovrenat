package com.my.posts;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.support.v7.app.AppCompatActivity;
import java.util.HashMap;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.ImageView;
import android.content.Intent;
import android.net.Uri;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import android.app.Activity;
import android.content.SharedPreferences;
import android.view.View;
import android.graphics.Typeface;
import com.bumptech.glide.Glide;

public class PostviewActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private HashMap<String, Object> post = new HashMap<>();
	private String like = "";
	
	private TextView name;
	private LinearLayout linear4;
	private LinearLayout linear1;
	private ScrollView vscroll1;
	private TextView textview5;
	private TextView author;
	private ImageView verify;
	private ImageView imageview1;
	private TextView theme;
	private LinearLayout linear3;
	private TextView textview3;
	private ImageView imageview3;
	private LinearLayout linear2;
	private ImageView imageview2;
	private TextView textview4;
	private LinearLayout linear5;
	private ImageView imageview4;
	
	private Intent intent = new Intent();
	private DatabaseReference data = _firebase.getReference("posts");
	private ChildEventListener _data_child_listener;
	private SharedPreferences save;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.postview);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		name = (TextView) findViewById(R.id.name);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		textview5 = (TextView) findViewById(R.id.textview5);
		author = (TextView) findViewById(R.id.author);
		verify = (ImageView) findViewById(R.id.verify);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		theme = (TextView) findViewById(R.id.theme);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		textview3 = (TextView) findViewById(R.id.textview3);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		textview4 = (TextView) findViewById(R.id.textview4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		save = getSharedPreferences("save", Activity.MODE_PRIVATE);
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				post = new HashMap<>();
				post.put("name", getIntent().getStringExtra("name"));
				post.put("theme", getIntent().getStringExtra("theme"));
				post.put("likes", String.valueOf((long)(Double.parseDouble(getIntent().getStringExtra("likes")) + 1)));
				post.put("text", getIntent().getStringExtra("text"));
				post.put("id", getIntent().getStringExtra("id"));
				data.child(getIntent().getStringExtra("id")).updateChildren(post);
				save.edit().putString(getIntent().getStringExtra("id"), "1").commit();
				textview4.setText("Вы поставили этой статье лайк!");
				imageview2.setVisibility(View.GONE);
				intent.setClass(getApplicationContext(), MainActivity.class);
				startActivity(intent);
				SketchwareUtil.showMessage(getApplicationContext(), "Спасибо за оценку!");
			}
		});
		
		imageview4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), ChatviewActivity.class);
				intent.putExtra("name", getIntent().getStringExtra("name"));
				intent.putExtra("theme", getIntent().getStringExtra("theme"));
				intent.putExtra("likes", getIntent().getStringExtra("likes"));
				intent.putExtra("id", getIntent().getStringExtra("id"));
				intent.putExtra("text", getIntent().getStringExtra("text"));
				intent.putExtra("author", getIntent().getStringExtra("author"));
				intent.putExtra("authorverify", getIntent().getStringExtra("authorverify"));
				intent.putExtra("imageurl", getIntent().getStringExtra("imageurl"));
				startActivity(intent);
			}
		});
		
		_data_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		data.addChildEventListener(_data_child_listener);
	}
	private void initializeLogic() {
		author.setText(getIntent().getStringExtra("author"));
		name.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/black.ttf"), 0);
		theme.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/bold.ttf"), 0);
		textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/meduim.ttf"), 0);
		textview4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/meduim.ttf"), 0);
		textview5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/meduim.ttf"), 0);
		author.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/bold.ttf"), 0);
		name.setText(getIntent().getStringExtra("name"));
		theme.setText(getIntent().getStringExtra("theme"));
		textview3.setText(getIntent().getStringExtra("text"));
		if (!getIntent().getStringExtra("imageurl").equals("")) {
			Glide.with(getApplicationContext()).load(Uri.parse(getIntent().getStringExtra("imageurl"))).into(imageview3);
		}
		else {
			imageview3.setVisibility(View.GONE);
		}
		if (save.getString("mail", "").equals("")) {
			textview4.setText("Авторизайтесь, чтобы оценивать статьи!");
			imageview2.setVisibility(View.GONE);
		}
		else {
			if (save.getString(getIntent().getStringExtra("id"), "").equals("")) {
				like = "0";
			}
			if (save.getString(getIntent().getStringExtra("id"), "").equals("1")) {
				textview4.setText("Вы поставили этой статье лайк!");
				imageview2.setVisibility(View.GONE);
			}
			if (getIntent().getStringExtra("authorverify").equals("no")) {
				verify.setVisibility(View.GONE);
			}
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
